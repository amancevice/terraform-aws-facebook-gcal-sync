"""
Facebook Events Sync
"""
from fest.facebook import FacebookPage  # noqa: F401
from fest.google import GoogleCalendar  # noqa: F401

__version__ = "5.2.0"
